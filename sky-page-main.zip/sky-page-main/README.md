# sky-page 光遇小站

> 一个简约耐看的光遇小站HTML+PHP页面
> 
> 自适应手机端和电脑端
> 
> 把与小伙伴在Sky·光遇这款游戏中的点点滴滴记录下来吧~

**[禁止商用]**


# 截图
截图是电脑与手机端截图
![Home](https://user-images.githubusercontent.com/61397705/218452088-beb23acd-fcee-48ea-8d3e-00fd8ec584fd.jpg)
![Image](https://user-images.githubusercontent.com/61397705/218452166-30507f34-5815-48e1-b6f2-b366fe3d5333.jpg)
![Video](https://user-images.githubusercontent.com/61397705/218452220-a8161efe-198f-4a80-9508-5ed7a02b2e9c.jpg)
![Book](https://user-images.githubusercontent.com/61397705/218452296-0784b3e3-ad30-456f-8fb8-1fa98813dfb7.jpg)
![Phone](https://user-images.githubusercontent.com/61397705/218452251-9a569bf0-2a91-46fc-a885-6c7146487902.jpg)



